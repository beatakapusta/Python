from . import util1

def utility():
    print("I'm a utility function... now I will call the useful function from util1!")
    util1.useful_function()
