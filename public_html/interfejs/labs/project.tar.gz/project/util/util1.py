def useful_function():
    print('I am useful!')
