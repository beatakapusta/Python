from ..util import util2

def main_function():
    print('I am the main function. Now I will call util2.utility()')
    util2.utility()
