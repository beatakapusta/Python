print("Welcome to the project!")

def x():
    print("Hi, My name is x and I am declared in project/__init__.py")
